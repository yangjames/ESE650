clear all
close all
clc

%data_collector
hmm_train
hmm_test